$(document).ready(function(){
	jQuery("ul.services li:nth-child(1)").addClass("item_1");
	jQuery("ul.services li:nth-child(2)").addClass("item_2");
	jQuery("ul.services li:nth-child(3)").addClass("item_3");

	jQuery("ul.popular li:nth-child(1)").addClass("item_1");
	jQuery("ul.popular li:nth-child(2)").addClass("item_2");
	jQuery("ul.popular li:nth-child(3)").addClass("item_3");
});