<?php /* Static Name: Title */ ?>
<?php get_template_part('title'); ?>